import javax.swing.JFrame;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Main implements ActionListener {
	
	static NorthWindDataBase db;
	static ResultSet rs = null; 
	static int valuesToShow;
	static boolean isRegularQuery = true;
	
	JLabel lbl1;
	JTextField txtID,txtFName,txtLName,txtStyleId1;
	JButton btn1,btnPrev,btnNext;
	
	JFrame frame;
	JPanel pnlNavAns;

	public static void main(String[] args) {
		Main obj = new Main();
		db = new NorthWindDataBase();
		obj.createUI();
	}
	
	
	private void createUI() 
	{
		frame = new JFrame("North Wind System");
		
		JPanel pnlInput = new JPanel(new GridLayout(9,2));
		String str;
		
		str = "View order details";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);
		
		str = "View customers Per Region";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);
		
		str = "Get Highest Price Products Per Category";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);	
		
		str = "Get Products For Sale";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);

			
		
		str = "Get Busiests Month";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);	
		
		str = "Show Available items in stock";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);	
		
		str = "Insert new product";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);	
		
		str = "Switch Shipments";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);	
		
		str = "Update Stock For product";
		lbl1 = new JLabel(str + ":");
		btn1 = new JButton(str);
		btn1.setActionCommand(str);
		btn1.addActionListener(this);
		
		pnlInput.add(lbl1);
		pnlInput.add(btn1);	
		
		JPanel pnlNavigate = new JPanel(new GridLayout(1,2));
		btnPrev = new JButton(" << ");
		btnPrev.setActionCommand("Prev");
		btnPrev.addActionListener(this);

		btnNext = new JButton(" >> ");
		btnNext.setActionCommand("Next");
		btnNext.addActionListener(this);

		pnlNavigate.add(btnPrev);
		pnlNavigate.add(btnNext);

		pnlNavAns = new JPanel(new GridLayout(5,2));
		buildBasicView();
		
		Container cn = frame.getContentPane();
		cn.setLayout(new BoxLayout(cn,BoxLayout.Y_AXIS));
		
		frame.add(pnlInput);
		frame.add(pnlNavAns);
		frame.add(pnlNavigate);
		
		setVisibleToLabels(0);
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation(dim.width/2-frame.getSize().width/2 - 250, dim.height/2-frame.getSize().height/2 - 300);
		
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                if(JOptionPane.showConfirmDialog(frame, "Are you sure ?") == JOptionPane.OK_OPTION){
                	db.close();
                	//frame.pack();
                	  frame.setDefaultCloseOperation(
                              JFrame.DISPOSE_ON_CLOSE);
            		frame.setVisible(false);
            		frame.dispose();
                }
            }
        });
		
		//If this will not be written, the only frame will be closed
		// but the application will be active.
		//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);

	}
	
	public void buildBasicView( ) {
		lbl1 = new JLabel("  ID : ");
		pnlNavAns.add(lbl1);
		lbl1 = new JLabel("Val");
		pnlNavAns.add(lbl1);
		
		lbl1 = new JLabel("  ID : ");
		pnlNavAns.add(lbl1);
		lbl1 = new JLabel("Val");
		pnlNavAns.add(lbl1);
		
		lbl1 = new JLabel("  ID : ");
		pnlNavAns.add(lbl1);
		lbl1 = new JLabel("Val");
		pnlNavAns.add(lbl1);
		
		lbl1 = new JLabel("  ID : ");
		pnlNavAns.add(lbl1);
		lbl1 = new JLabel("Val");
		pnlNavAns.add(lbl1);

	}
	
	public void setVisibleToLabels(int numberOfVisible) {
		numberOfVisible = numberOfVisible * 2;
		int index = 0;
		for (int i = 0; i < pnlNavAns.getComponents().length; i++) {
			if (index < numberOfVisible) 
					 pnlNavAns.getComponents()[index++].setVisible(true);
			
			else 
				 pnlNavAns.getComponents()[index++].setVisible(false);

		}			
	}
	
	public void setLabelsNames(String[] labels) {
		for (int i = 0; i < labels.length; i++) {
			((JLabel)pnlNavAns.getComponents()[i *2]).setText(labels[i]);
			((JLabel)pnlNavAns.getComponents()[i *2 + 1]).setText("Val");
		}
	}


	@Override
	public void actionPerformed(ActionEvent evt) {
		try {
			
			String action = evt.getActionCommand();
			if(action.equals("View order details"))
			{
				String[] labels = new String[]{"Order ID:","Customer ID:","Products Per Order:"}; 
				setLabelsNames(labels);
				valuesToShow = labels.length;
				setVisibleToLabels(valuesToShow);
				rs = db.getProductQuantitySoldToCustomer();	
				rs.next();
				populateValue();
				
				isRegularQuery = true;
				setVisibleToStordePrucedure();
			}
			else if(action.equals("View customers Per Region"))
			{
				String[] labels = new String[]{"Company Name:","Region:"}; 
				setLabelsNames(labels);
				valuesToShow = labels.length;
				setVisibleToLabels(valuesToShow);
				rs = db.getHighestTotalOrderCustomerPerRegion();
				rs.next();
				populateValue();	
				
				isRegularQuery = true;
				setVisibleToStordePrucedure();
			}
			else if(action.equals("Get Products For Sale"))
			{
				String[] labels = new String[]{"ProductID:","ProductName:"}; 
				setLabelsNames(labels);
				valuesToShow = labels.length;
				setVisibleToLabels(valuesToShow);
				rs = db.getProductsForSales();
				rs.next();
				populateValue();	
				
				isRegularQuery = false;
				setVisibleToStordePrucedure();
			}
			else if(action.equals("Get Highest Price Products Per Category"))
			{
				String[] labels = new String[]{"ProductName:", "CategoryID:", "UnitPrice:"}; 
				setLabelsNames(labels);
				valuesToShow = labels.length;
				setVisibleToLabels(valuesToShow);
				rs = db.getHighestPriceProductsPerCategory();
				rs.next();
				populateValue();
				
				isRegularQuery = true;
				setVisibleToStordePrucedure();
			}
			else if(action.equals("Get Busiests Month"))
			{
				String[] labels = new String[]{"Month Name:", "Total Price:"}; 
				setLabelsNames(labels);
				valuesToShow = labels.length;
				setVisibleToLabels(valuesToShow);
				rs = db.getBusiestsMonth();
				rs.next();
				populateValue();
				
				isRegularQuery = true;
				setVisibleToStordePrucedure();
			}
			//"Show Available items in stock"
			else if(action.equals("Show Available items in stock"))
			{
			
				
				JTextField f1 = new JTextField();
				//JTextField f2 = new JTextField();

				Object[] fields = {
						"Enter quantity:", f1};
				
				JOptionPane.showConfirmDialog(
	                    null,
	                    fields,
	                    "Show quantity less than",
	                    JOptionPane.PLAIN_MESSAGE);
				
				String s = f1.getText();

				//If a string was returned, say so.
				if ((s != null) && (s.length() > 0) && checkIfInputIsDigit(s) ) {
					btnPrev.setEnabled(false);
					String[] labels = new String[]{"Product ID:", "Product Name:", "Unit Price:", "Units In Stock:"}; 
					setLabelsNames(labels);
					valuesToShow = labels.length;
					setVisibleToLabels(valuesToShow);
					rs = db.getStockLessThan(Integer.parseInt(s));
					rs.next();
					populateValue();
				}
				else {
					showMessage("Quntity can't be empty and must be only numeric", "Quantity", JOptionPane.ERROR_MESSAGE);
				}
				isRegularQuery = false;
				setVisibleToStordePrucedure();
			}
			else if(action.equals("Insert new product"))
			{
				JTextField f1 = new JTextField();
				JTextField f2 = new JTextField();
				JTextField f3 = new JTextField();
				JTextField f4 = new JTextField();
				JTextField f5 = new JTextField();
				JTextField f6 = new JTextField();
				JTextField f7 = new JTextField();
				JTextField f8 = new JTextField();
				JTextField f9 = new JTextField();
				

				Object[] fields = {
						"Product name:", f1,
						"Supplier ID:", f2,
						"Category ID:", f3,
						"Quantity:", f4,
						"Price:", f5,
						"Units In Stock:", f6,
						"Units On Order:", f7,
						"Reorder Level:", f8,
						"Discontinued:", f9
						};
				
				JOptionPane.showConfirmDialog(
	                    null,
	                    fields,
	                    "Insert new product",
	                    JOptionPane.PLAIN_MESSAGE);
				
				String str1 = f1.getText(); //== null ? "null" : f1.getText();
				String str2 = f2.getText().length() == 0 ? "1" : f2.getText();
				String str3 = f3.getText().length() == 0 ? "1" : f3.getText();
				String str4 = f4.getText().length() == 0 ? "null" : f4.getText();
				String str5 = f5.getText().length() == 0 ? "0" : f5.getText();
				String str6 = f6.getText().length() == 0 ? "0" : f6.getText();
				String str7 = f7.getText().length() == 0 ? "0" : f7.getText();
				String str8 = f8.getText().length() == 0 ? "0" : f8.getText();
				String str9 = f9.getText(); //== null ? "null" : f9.getText();

				
				if ((str1 == null) || (str1.length() == 0))
					showMessage("Product name can't be empty", "Product name", JOptionPane.ERROR_MESSAGE);
				else if ((str9 == null) || (str9.length() == 0))
					showMessage("Discontinued name can't be empty", "Discontinued", JOptionPane.ERROR_MESSAGE);
				else
				{
					valuesToShow = 0;
					setVisibleToLabels(valuesToShow);
					int result = db.insertNewProduct(str1, str2, str3, str4, str5, str6, str7, str8, str9);
					if (result == 1) {
						showMessage("New product successfully created", "New product", JOptionPane.INFORMATION_MESSAGE);
					}
					
				}
				isRegularQuery = true;
				setVisibleToStordePrucedure();
			}
			else if(action.equals("Switch Shipments"))
			{
				JTextField f1 = new JTextField();
				JTextField f2 = new JTextField();
				JTextField f3 = new JTextField();
				
				String[] month= {"1","2","3","4","5","6","7","8","9","10","11","12"};
				JComboBox<String> jcm = new JComboBox<String>(month);
				
				Object[] fields = {
						"Shipper 1:", f1,
						"Shipper 2:", f2,
						"Year:", f3,
						"Month:", jcm};
				
				JOptionPane.showConfirmDialog(
	                    null,
	                    fields,
	                    "Switch Shippers",
	                    JOptionPane.PLAIN_MESSAGE);
					
				if ((f1 == null) || (f1.getText().length() == 0) || !checkIfInputIsDigit(f1.getText()) )
					showMessage("Shipper ID 1 can't be empty and must be only numeric", "Shiper ID 1", JOptionPane.ERROR_MESSAGE);
				else if ((f2 == null) || (f2.getText().length() == 0) || !checkIfInputIsDigit(f2.getText()) )
					showMessage("Shipper ID 2 can't be empty and must be only numeric", "Shiper ID 2", JOptionPane.ERROR_MESSAGE);
				else if ((f3 == null) || (f3.getText().length() == 0) || !checkIfInputIsDigit(f3.getText()) )
					showMessage("Year can't be empty and must be only numeric", "Year", JOptionPane.ERROR_MESSAGE);
				else {
					db.switchShips(Integer.parseInt(f1.getText()), Integer.parseInt(f2.getText()), Integer.parseInt(f3.getText()), Integer.parseInt(jcm.getSelectedItem().toString()));
				}

			}
			else if(action.equals("Update Stock For product"))
			{
				JTextField f1 = new JTextField();
				JTextField f2 = new JTextField();
				
				Object[] fields = {
						"Product ID:", f1,
						"Quantity to reduce:", f2};
				
				JOptionPane.showConfirmDialog(
	                    null,
	                    fields,
	                    "Update Product Quntity",
	                    JOptionPane.PLAIN_MESSAGE);
				
				if ((f1 == null) || (f1.getText().length() == 0) || !checkIfInputIsDigit(f1.getText()) )
					showMessage("Product ID can't be empty and must be only numeric", "Product ID", JOptionPane.ERROR_MESSAGE);
				else if ((f2 == null) || (f2.getText().length() == 0) || !checkIfInputIsDigit(f2.getText()) )
					showMessage("Quantity can't be empty and must be only numeric", "Quantity", JOptionPane.ERROR_MESSAGE);
				else {
					if (db.updateStock(Integer.parseInt(f1.getText()), Integer.parseInt(f2.getText())) == 1)
						showMessage("Updated successfully", "Update product quntity", JOptionPane.INFORMATION_MESSAGE);
					else
						showMessage("Updated Rejected, Not enough items in stock", "Update product quntity", JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
			else if(action.equals("Prev"))
			{
				//rs.previous();
				prevNavigation();
			}
			else if(action.equals("Next"))
			{
				//rs.next();
				nextNavigation();
	
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private boolean checkIfInputIsDigit(String s) {
		for (int i = 0; i < s.length(); i ++) {
			if(!Character.isDigit(s.charAt(i))) {
				return false;
			}
		}
		return true;
	}
	
	private void populateValue() throws SQLException
	{
		
		//rs.refreshRow();
		for (int i = 0; i < valuesToShow; i++) {
			((JLabel)pnlNavAns.getComponents()[i *2 + 1]).setText(rs.getString(i +1));
		}
	}
	
	private void nextNavigation() throws SQLException
	{
		if (rs.next())
			populateValue();
	}
	
	private void prevNavigation() throws SQLException
	{
		if (rs.previous())
			populateValue();
	}
	
	public void showMessage(String message, String header, int type) {
		JFrame frame = new JFrame(header);
		JOptionPane.showMessageDialog(frame,
				message,
				header,
				type);
	}
	
	public void setVisibleToStordePrucedure() {
		btnPrev.setEnabled(isRegularQuery);
	}
}
