

import java.io.FileNotFoundException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class NorthWindDataBase {  

	static String connectionUrl 
		= "jdbc:sqlserver://localhost;databaseName=NorthWind;integratedSecurity=true;" ;  
	static Connection con = null;  
	static Statement stmt = null;  
	static ResultSet rs = null;  
	static CallableStatement  cstmt = null;
	
	public NorthWindDataBase() {
		init();
	}
	
	public void close() {
		if (con != null) 
			try { 
				con.close(); 
			} catch(Exception e) {
				e.printStackTrace();
			}  
	}

	public static void init() {

		try {  
			// Establish the connection.  
			
			System.out.println("Trying to set a connection  to sql server...");
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
			con = DriverManager.getConnection(connectionUrl);  
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.exit(0);
		} catch (SQLException e) {
			e.printStackTrace();
			System.exit(0);
		}
		System.out.println("connection was set!\n");

	}

	
	public ResultSet getProductQuantitySoldToCustomer() {
		try {  
			String SQL = "SELECT o.OrderID, o.CustomerID, COUNT(ProductID) AS totalProductsPerOrderId "
					 + "FROM Orders o JOIN OrderDetails od ON o.OrderID = od.OrderID "
					 + "GROUP BY o.OrderID, o.CustomerID "
			         + "ORDER BY COUNT(ProductID) DESC";
			
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE); 
			rs = stmt.executeQuery(SQL);
			
			return rs;
		}
			// Handle any errors that may have occurred.  

			catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
	}
	
	public ResultSet getHighestTotalOrderCustomerPerRegion() {
		try {  
			// Create and execute an SQL statement that returns some data.  
			String SQL = "SELECT c.CompanyName , c.Region "
						+ "FROM Customers c "
						+ "WHERE c.CustomerID IN "
											+ "( "
											+ "SELECT TOP 1 o.CustomerID "
											+ "FROM Orders o JOIN OrderDetails od ON o.OrderID = od.OrderID "
											+ "WHERE c.Region = o.ShipRegion "
											+ "GROUP BY o.CustomerID " 
											+ "ORDER BY ROUND(SUM(od.Quantity * od.UnitPrice * (1- od.Discount)),3) "
										    + ") ";
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);  
			rs = stmt.executeQuery(SQL);  
		}
			// Handle any errors that may have occurred.  

			catch (SQLException e) {
				e.printStackTrace();
			}
		return rs;
	}
	
	public ResultSet getHighestPriceProductsPerCategory() {
		try {  
			// Create and execute an SQL statement that returns some data.  
			String SQL = "SELECT p.ProductName, p.CategoryID, p.UnitPrice "
						+ "FROM Products p "
						+ "WHERE p.UnitPrice IN ( SELECT MAX(UnitPrice) "
												+ "FROM Products 	" 
												+ "WHERE CategoryID = p.CategoryID "
												+ "GROUP BY CategoryID) "
						+ "ORDER BY p.UnitPrice DESC ";
			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);  
			rs = stmt.executeQuery(SQL);  
		}
			// Handle any errors that may have occurred.  

			catch (SQLException e) {
				e.printStackTrace();
			}
		return rs;
	}
	
	public ResultSet getBusiestsMonth() {
		try {  
			// Create and execute an SQL statement that returns some data.  
			String SQL = "SELECT TOP 1 DATENAME(month, o.OrderDate) AS [Month Name],"
					 	+ "	ISNULL(ROUND(SUM(TotalOrdersAndPrice.TotalPrice),2),0) AS TotalPrice "
						+ "FROM Orders o JOIN "
							+ "( SELECT o.OrderID, COUNT(DISTINCT(od.OrderID)) AS TotalOrders,"
							+ "SUM(od.Quantity * od.UnitPrice * (1- od.Discount)) AS TotalPrice "
							+ "FROM Orders o JOIN OrderDetails od ON o.OrderID = od.OrderID "
							+ "WHERE YEAR(o.OrderDate) = 2016 "
							+ "GROUP BY o.OrderID " 
							+ " ) AS TotalOrdersAndPrice ON o.OrderID = TotalOrdersAndPrice.OrderID "
					    + "GROUP BY DATENAME(MONTH, o.OrderDate) "
			            + "ORDER BY TotalPrice DESC ";

			stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
					ResultSet.CONCUR_UPDATABLE);  
			rs = stmt.executeQuery(SQL);  
		}
			// Handle any errors that may have occurred.  

			catch (SQLException e) {
				e.printStackTrace();
			}
		return rs;
	}
	
	
	
	public ResultSet getProductsForSales() {
		try {  
			cstmt =	con.prepareCall("{Call getProductsForSales}");
			
			rs =  cstmt.executeQuery();

		}catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}

	public ResultSet getStockLessThan(int quantity) {
		try {  
			cstmt = 
					con.prepareCall("{Call stockLessThan(?)}");
			cstmt.setInt(1, quantity);

			rs =  cstmt.executeQuery();

		}catch (SQLException e) {
			e.printStackTrace();
		}

		return rs;
	}  


	
	public int insertNewProduct(String ProductName		,
			String SupplierID		,
			String CategoryID		,
			String QuantityPerUnit ,
			String UnitPrice		,
			String UnitsInStock	,
			String UnitsOnOrder	,
			String ReorderLevel	,
			String Discontinued) {
		int result = -1;
		try {   
			String SQL1 = "INSERT INTO Products"
					+ " VALUES ('" + ProductName + "','" + SupplierID + "','"+ CategoryID + "','"+ QuantityPerUnit +
					"','"+ UnitPrice + "','"+ UnitsInStock + "','"+ UnitsOnOrder + "','"+ ReorderLevel + "','"+ Discontinued + "')";  
			System.out.println(SQL1);
			stmt = con.createStatement();  
			result = stmt.executeUpdate(SQL1);  


		}  

		// Handle any errors that may have occurred.  

		catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public void switchShips(int company1, int company2, int year, int month) {
		try {
		cstmt = 
				con.prepareCall("{call switchShips(?,?,?,?)}");
		cstmt.setInt(1, company1);
		cstmt.setInt(2, company2);
		cstmt.setInt(3, year);
		cstmt.setInt(4, month);

		cstmt.executeUpdate();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public int updateStock(int productID, int newQuantity) {
		try {
			cstmt = con.prepareCall("{call updateStock(?,?)}");
		
			cstmt.setInt(1, productID);
			cstmt.setInt(2, newQuantity);
			
			cstmt.executeUpdate();
			return cstmt.getUpdateCount();
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}
	
}  